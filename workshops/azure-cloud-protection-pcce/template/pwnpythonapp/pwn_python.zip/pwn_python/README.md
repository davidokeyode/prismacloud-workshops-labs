# pwn_python

Simple flask application that lets you execute any
command via a url argument.

Example: `http://<ip>:5000/?cmd=env`